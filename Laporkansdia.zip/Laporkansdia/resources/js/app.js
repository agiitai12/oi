require('./bootstrap');

require('alpinejs');
